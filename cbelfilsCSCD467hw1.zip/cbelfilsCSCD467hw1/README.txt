Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467hw1.zip, you get a folder named cbelfilsCSCD467hw1.
To Compile:
	cd into folder cbelfilsCSCD467hw1, javac *.java
To Run
	java Inputter