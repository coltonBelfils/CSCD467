Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467hw3.zip, you get a folder named cbelfilsCSCD467hw3.
To Compile:
	cd into folder cbelfilsCSCD467hw3, javac *.java
To Run
	java ParallelSearchCoarse

test.txt is the test file you gave us
test2.txt is a test file I made

It alwase works on the file I made, but on the longer file something doesn't work everything seems fine though