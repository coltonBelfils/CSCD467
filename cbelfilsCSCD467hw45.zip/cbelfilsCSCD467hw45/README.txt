Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467hw45.zip, you get a folder named cbelfilsCSCD467hw45.
To Compile:
	cd into folder cbelfilsCSCD467hw45, javac *.java
To Run
	java CapitalizeServer and run java ParallelClient to symulate connections