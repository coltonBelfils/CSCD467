Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467hw6.zip, you get a folder named cbelfilsCSCD467hw6.
To Compile:
	cd into folder cbelfilsCSCD467hw6, javac *.java
To Run
	java DragDropFiles