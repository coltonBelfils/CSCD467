Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467Lab2.zip, you get a folder named cbelfilsCSCD467Lab2.
To Compile:
	cd into folder cbelfilsCSCD467Lab2, javac *.java
To Run
	java mainThread