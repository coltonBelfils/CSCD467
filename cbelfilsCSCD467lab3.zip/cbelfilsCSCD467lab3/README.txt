Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467Lab3.zip, you get a folder named cbelfilsCSCD467Lab3.
To Compile:
	cd into folder cbelfilsCSCD467Lab3, javac *.java
To Run
	java Alternation