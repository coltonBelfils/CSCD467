Name: Colton Belfils
Description: unzip the submitted cbelfilsCSCD467Lab4.zip, you get a folder named cbelfilsCSCD467Lab4.
To Compile:
	cd into folder cbelfilsCSCD467Lab4, javac *.java
To Run
	java MainThread <number of threads> <number to count to>